# TweakScale Companion :: SMCE :: Change Log

* 2023-1005: 0.0.2.0 (LisiasT) for KSP >= 1.4
	+ Adds Support for:
		-  New parts from Large Ship Parts 3.9.3 BB2
		-  SM Marine
	+ Updates the Documentation
	+ Implements Issues:
		- [#15](https://github.com/TweakScale/Companion/issues/15) Extend the fix implemented on TweakScaleCompanion_NF#2 to every Companion
* 2021-0216: 0.0.1.1 (LisiasT) for KSP >= 1.4
	+ Complete revamp of the Large Ship Parts' patches
* 2020-0413: 0.0.1.0 (LisiasT) for KSP >= 1.4
	+ Initial Release
