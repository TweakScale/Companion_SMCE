# TweakScale Companion :: SMCE :: Known Issues

* Some patches from the target addons aged terribly, playing havoc on modern KSPs. There is no other choice but to overwrite some files with files where the terrible patches are removed.
	+ You **MUST** replace these files with the ones provided by this package.
	+ They are:
		- LShipPartsModern
		- LShipPartsRequired  
